import sqlite3

conn = sqlite3.connect('stu_database.db')
print('db connected succesfully')

conn.execute('CREATE TABLE students (name TEXT, password TEXT, email TEXT,dept TEXT)')
print("Table created successfully")
conn.close()