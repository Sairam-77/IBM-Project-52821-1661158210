
from asyncio.windows_events import NULL
from contextlib import nullcontext
from flask import Flask, render_template, request, redirect, session
import sqlite3 as sql

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/addstd')
def addstd():
    return render_template('register.html')

@app.route('/register',methods=['POST','GET'])
def register():
    if request.method=='POST':
        try:
            name = request.form['name']
            email=request.form['email']
            password = request.form['password']
            dept = request.form['dept']

            with sql.connect("stu_database.db") as con:
                cur = con.cursor()
                cur.execute("INSERT INTO students (name,password,email,dept) VALUES (?,?,?,?)",(name,password,email,dept) )
                con.commit()
                msg = "Register successfull please login!"
        except:
         con.rollback()
         msg = "error in insert operation"
      
        finally:
         return render_template("login.html",msg = msg)
         con.close()


@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/check',methods=['POST','GET'])
def check():
     if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        con = sql.connect("stu_database.db")
        curs = con.cursor()
        curs.execute("SELECT * FROM students where email = (?)",[email])
        user = list(curs.fetchone())
        
        if user:
            if user[1]==password:   
                msg = user
                return render_template('home.html', msg = msg)
            else:
                msg = 'password was inccoret!'
                return render_template('login.html', msg = msg)
        else:
            msg = "Account not found"
            return render_template('login.html', msg = msg)
     else:
         msg = 'Error in methods'
         return render_template('login.html', msg = msg)

